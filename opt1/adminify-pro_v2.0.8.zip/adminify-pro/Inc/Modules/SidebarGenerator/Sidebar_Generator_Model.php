<?php

namespace WPAdminify\Inc\Modules\SidebarGenerator;

use WPAdminify\Inc\Base_Model;

abstract class Sidebar_Generator_Model extends Base_Model
{
    protected $prefix = '_wp_adminify_sidebar_settings';
}
