<?php

namespace WPAdminify\Inc\Modules\LoginCustomizer\Inc;

use WPAdminify\Inc\Base_Model;

abstract class Customize_Model extends Base_Model
{

    protected $prefix = 'jltwp_adminify_login';
}
