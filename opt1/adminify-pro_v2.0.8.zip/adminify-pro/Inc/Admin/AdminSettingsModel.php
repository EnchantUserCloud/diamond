<?php

namespace WPAdminify\Inc\Admin;

use WPAdminify\Inc\Base_Model;

abstract class AdminSettingsModel extends Base_Model
{
    protected $prefix = '_wpadminify';
}
